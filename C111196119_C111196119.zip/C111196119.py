import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-1.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-2.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-3.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-4.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-5.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-6.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-7.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-8.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-9.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-10.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-11.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-12.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-13.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-14.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-15.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-16.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-17.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-18.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-19.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()

import requests
from bs4 import BeautifulSoup

url = "https://www.nkust.edu.tw/p/403-1000-1363-20.php?Lang=zh-tw"
html = requests.get(url).text
sel = "#pageptlist > div > div > div > div.d-txt > div.mtitle > a"
soup = BeautifulSoup(html, "lxml")
target = soup.select(sel)
fp = open("c111196119-news.txt", "w", encoding="utf-8")
for t in target:
    print(t.text.strip())
    fp.write(t.text.strip()+"\n")
fp.close()